%plot_model_fits

clear all; 
close all; 
clc; 

plate = growthFit5('test_data.xlsx'); % generate a cell array with the data


%plots the data and log-linear, logistic, and gompertz fits to the data

%k is number of columns of data 
k = size(plate, 2) - 1; 

%average technical replicates
for i = 1:k
    
end

for i=1:k 
   
    %log-linear
        subplot(k, 3, 1 + 3*(i - 1)); 
        plot(plate{i}.time, plate{i}.data, 'k.'); 
        hold on; 
        plot(plate{i}.loglinear.curveFit(:,1), plate{i}.loglinear.curveFit(:,2), 'r');
        xlabel('time (hours)'); 
        xlim([0, 15]);
        ylabel(plate{i}.mutant); 
        if i == 1
           title('log-linear');
        end
    
    %logistic
        subplot(k, 3, 2 + 3*(i - 1)); 
        plot(plate{i}.time, plate{i}.data, 'k.'); 
        hold on; 
        plot(plate{i}.logistic.curveFit(:,1), plate{i}.logistic.curveFit(:,2), 'm');
        xlabel('time (hours)'); 
        if i == 1
           title('logistic');
        end
        %title(plate{i}.mutant);
 
        %gompertz
        subplot(k, 3, 3 + 3*(i - 1)); 
        plot(plate{i}.time, plate{i}.data, 'k.'); 
        hold on; 
        plot(plate{i}.gompertz.curveFit(:,1), plate{i}.gompertz.curveFit(:,2), 'b');
        xlabel('time (hours)'); 
        if i == 1
            title('gompertz');
        end
   
   
end
    
    